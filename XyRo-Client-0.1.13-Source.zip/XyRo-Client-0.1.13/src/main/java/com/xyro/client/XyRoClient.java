package com.xyro.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public final class XyRoClient implements ClientModInitializer {
    private static KeyMapping openMenuKey;

    @Override
    public void onInitializeClient() {
        XyRoModules.load();
        XyRoHudLayout.load();
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.xyroclient.open_menu", GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null) client.setScreen(new XyRoScreen());
            }
        });

        // Real in-game FPS overlay. It is intentionally lightweight and off by default.
        HudRenderCallback.EVENT.register((graphics, tickCounter) -> {
            Minecraft client = Minecraft.getInstance();
            if (client.player == null) return;

            int fps = client.getFps();
            if (XyRoModules.isEnabled("FPS Counter")) {
                int fpsColor = fps >= 90 ? 0xFF83F0B0 : fps >= 45 ? 0xFFFFD479 : 0xFFFF8585;
                drawHudText(graphics, client, "✦ " + fps + " FPS", "fps", fpsColor);
            }

            if (XyRoModules.isEnabled("Memory Monitor")) {
                Runtime runtime = Runtime.getRuntime();
                long usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024L * 1024L);
                long maxMb = runtime.maxMemory() / (1024L * 1024L);
                drawHudText(graphics, client, "RAM " + usedMb + " / " + maxMb + " MB", "memory", 0xFFD9C5FF);
            }
        });
    }

    private static void drawHudText(net.minecraft.client.gui.GuiGraphics graphics, Minecraft client,
                                    String text, String element, int fallbackColor) {
        float scale = XyRoHudLayout.scale(element);
        int color = XyRoHudLayout.color(element);
        graphics.pose().pushPose();
        graphics.pose().translate(XyRoHudLayout.x(element), XyRoHudLayout.y(element));
        graphics.pose().scale(scale, scale);
        graphics.drawString(client.font, text, 0, 0, color == 0 ? fallbackColor : color, true);
        graphics.pose().popPose();
    }

    static Component text(String value) { return Component.literal(value); }
}
