package com.xyro.client;

import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Saved screen positions for movable XyRo HUD elements. */
public final class XyRoHudLayout {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("xyro-hud.properties");
    private static int fpsX = 8, fpsY = 8, memoryX = 8, memoryY = 22;
    private static float fpsScale = 1.0f, memoryScale = 1.0f;
    private static int fpsColor = 0xFFB77BFF, memoryColor = 0xFFD9C5FF;
    private static final int[] PALETTE = {0xFFB77BFF, 0xFFFFFFFF, 0xFF66D9EF, 0xFFFFC66D};
    private static boolean loaded;

    private XyRoHudLayout() {}

    public static void load() {
        if (loaded) return;
        loaded = true;
        if (!Files.isRegularFile(FILE)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(FILE)) {
            p.load(in);
            fpsX = integer(p, "fpsX", fpsX); fpsY = integer(p, "fpsY", fpsY);
            memoryX = integer(p, "memoryX", memoryX); memoryY = integer(p, "memoryY", memoryY);
            fpsScale = decimal(p, "fpsScale", fpsScale); memoryScale = decimal(p, "memoryScale", memoryScale);
            fpsColor = integer(p, "fpsColor", fpsColor); memoryColor = integer(p, "memoryColor", memoryColor);
            fpsScale = clampScale(fpsScale); memoryScale = clampScale(memoryScale);
        } catch (IOException e) {
            System.err.println("[XyRo] Could not load HUD layout: " + e.getMessage());
        }
    }

    private static int integer(Properties p, String key, int fallback) {
        try { return Integer.parseInt(p.getProperty(key, Integer.toString(fallback))); }
        catch (NumberFormatException ignored) { return fallback; }
    }

    public static int x(String element) { load(); return "memory".equals(element) ? memoryX : fpsX; }
    public static int y(String element) { load(); return "memory".equals(element) ? memoryY : fpsY; }
    public static float scale(String element) { load(); return "memory".equals(element) ? memoryScale : fpsScale; }
    public static int color(String element) { load(); return "memory".equals(element) ? memoryColor : fpsColor; }

    public static void changeScale(String element, float amount) {
        load();
        if ("memory".equals(element)) memoryScale = clampScale(memoryScale + amount);
        else fpsScale = clampScale(fpsScale + amount);
        save();
    }

    public static void cycleColor(String element) {
        load();
        if ("memory".equals(element)) memoryColor = nextColor(memoryColor);
        else fpsColor = nextColor(fpsColor);
        save();
    }

    private static int nextColor(int current) {
        for (int i = 0; i < PALETTE.length; i++) if (PALETTE[i] == current) return PALETTE[(i + 1) % PALETTE.length];
        return PALETTE[0];
    }

    private static float clampScale(float value) { return Math.max(0.6f, Math.min(2.0f, value)); }
    private static float decimal(Properties p, String key, float fallback) {
        try { return Float.parseFloat(p.getProperty(key, Float.toString(fallback))); }
        catch (NumberFormatException ignored) { return fallback; }
    }

    public static void move(String element, int x, int y) {
        load();
        if ("memory".equals(element)) { memoryX = Math.max(0, x); memoryY = Math.max(0, y); }
        else { fpsX = Math.max(0, x); fpsY = Math.max(0, y); }
    }

    public static void save() {
        load();
        Properties p = new Properties();
        p.setProperty("fpsX", Integer.toString(fpsX)); p.setProperty("fpsY", Integer.toString(fpsY));
        p.setProperty("memoryX", Integer.toString(memoryX)); p.setProperty("memoryY", Integer.toString(memoryY));
        p.setProperty("fpsScale", Float.toString(fpsScale)); p.setProperty("memoryScale", Float.toString(memoryScale));
        p.setProperty("fpsColor", Integer.toString(fpsColor)); p.setProperty("memoryColor", Integer.toString(memoryColor));
        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream out = Files.newOutputStream(FILE)) { p.store(out, "XyRo movable HUD layout"); }
        } catch (IOException e) {
            System.err.println("[XyRo] Could not save HUD layout: " + e.getMessage());
        }
    }
}
