package com.xyro.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** Simple touch/mouse-friendly editor for the FPS and memory HUD positions. */
public final class XyRoHudEditorScreen extends Screen {
    private static final int PURPLE = 0xFFB77BFF;
    private String dragging;
    private int dragOffsetX, dragOffsetY;

    public XyRoHudEditorScreen() { super(Component.literal("XyRo HUD Editor")); }

    @Override
    protected void init() {
        int panelW = Math.min(430, width - 24), panelH = Math.min(230, height - 24);
        int left = (width - panelW) / 2, top = (height - panelH) / 2;
        int row1 = top + panelH - 66, row2 = top + panelH - 39;
        addRenderableWidget(Button.builder(Component.literal("FPS −"), b -> XyRoHudLayout.changeScale("fps", -0.1f))
                .bounds(left + 12, row1, 54, 20).build());
        addRenderableWidget(Button.builder(Component.literal("FPS +"), b -> XyRoHudLayout.changeScale("fps", 0.1f))
                .bounds(left + 70, row1, 54, 20).build());
        addRenderableWidget(Button.builder(Component.literal("FPS COLOR"), b -> XyRoHudLayout.cycleColor("fps"))
                .bounds(left + 128, row1, 82, 20).build());
        addRenderableWidget(Button.builder(Component.literal("RAM −"), b -> XyRoHudLayout.changeScale("memory", -0.1f))
                .bounds(left + 12, row2, 54, 20).build());
        addRenderableWidget(Button.builder(Component.literal("RAM +"), b -> XyRoHudLayout.changeScale("memory", 0.1f))
                .bounds(left + 70, row2, 54, 20).build());
        addRenderableWidget(Button.builder(Component.literal("RAM COLOR"), b -> XyRoHudLayout.cycleColor("memory"))
                .bounds(left + 128, row2, 82, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int panelW = Math.min(430, width - 24), panelH = Math.min(230, height - 24);
        int left = (width - panelW) / 2, top = (height - panelH) / 2;
        g.fill(left, top, left + panelW, top + panelH, 0xF00B0910);
        g.fill(left, top, left + panelW, top + 2, PURPLE);
        g.drawString(font, "✦ XYRO HUD EDITOR", left + 12, top + 12, 0xFFFFFFFF, true);
        g.drawString(font, "Drag the preview labels to move them.", left + 12, top + 29, 0xFFBDB4C8, false);
        g.drawString(font, "Positions save when you close this screen.", left + 12, top + 43, 0xFFBDB4C8, false);

        XyRoHudLayout.load();
        int fx = clampX(XyRoHudLayout.x("fps"), "✦ 144 FPS");
        int fy = clampY(XyRoHudLayout.y("fps"));
        int mx = clampX(XyRoHudLayout.x("memory"), "RAM 2048 / 4096 MB");
        int my = clampY(XyRoHudLayout.y("memory"));
        drawPreview(g, "✦ 144 FPS", "fps", fx, fy);
        drawPreview(g, "RAM 2048 / 4096 MB", "memory", mx, my);
        g.drawString(font, "SCALE 0.6x–2.0x  •  COLORS CYCLE", left + 12, top + 61, 0xFFBDB4C8, false);
        g.drawString(font, "Drag previews • ESC saves & closes", left + 12, top + panelH - 15, 0xFFBDB4C8, false);
        super.render(g, mouseX, mouseY, delta);
    }

    private void drawPreview(GuiGraphics g, String label, String element, int x, int y) {
        float scale = XyRoHudLayout.scale(element);
        g.pose().pushPose();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.fill(-4, -3, font.width(label) + 5, 12, 0xC020172B);
        g.drawString(font, label, 0, 0, XyRoHudLayout.color(element), true);
        g.pose().popPose();
        String meta = String.format(java.util.Locale.ROOT, "%.1fx", scale);
        g.drawString(font, meta, x + Math.round(font.width(label) * scale) + 8, y + 2, 0xFFBDB4C8, false);
    }

    private int clampX(int x, String text) { return Math.max(4, Math.min(x, width - font.width(text) - 5)); }
    private int clampY(int y) { return Math.max(4, Math.min(y, height - 14)); }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (inside(mouseX, mouseY, "fps", "✦ 144 FPS")) dragging = "fps";
            else if (inside(mouseX, mouseY, "memory", "RAM 2048 / 4096 MB")) dragging = "memory";
            if (dragging != null) {
                dragOffsetX = (int) mouseX - XyRoHudLayout.x(dragging);
                dragOffsetY = (int) mouseY - XyRoHudLayout.y(dragging);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean inside(double mx, double my, String element, String label) {
        int x = XyRoHudLayout.x(element), y = XyRoHudLayout.y(element);
        float scale = XyRoHudLayout.scale(element);
        return mx >= x - 4 && mx <= x + font.width(label) * scale + 5 && my >= y - 3 && my <= y + 12 * scale;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (dragging != null && button == 0) {
            String label = "memory".equals(dragging) ? "RAM 2048 / 4096 MB" : "✦ 144 FPS";
            float scale = XyRoHudLayout.scale(dragging);
            int nextX = Math.max(4, Math.min((int) mouseX - dragOffsetX, width - Math.round(font.width(label) * scale) - 5));
            int nextY = Math.max(4, Math.min((int) mouseY - dragOffsetY, height - Math.round(14 * scale)));
            XyRoHudLayout.move(dragging, nextX, nextY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && dragging != null) {
            dragging = null;
            XyRoHudLayout.save();
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void onClose() {
        XyRoHudLayout.save();
        super.onClose();
    }

    @Override public boolean isPauseScreen() { return false; }
}
