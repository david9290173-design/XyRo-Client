package com.xyro.client;

import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.server.level.ParticleStatus;

/** Applies conservative, reversible vanilla graphics settings for lower-end devices. */
public final class XyRoPerformance {
    private XyRoPerformance() {}

    /** Applies the XyRo Low-End preset using Minecraft's own client options. */
    public static void applyLowEndPreset() {
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.options == null) return;

        var options = client.options;
        options.renderDistance().set(6);
        options.simulationDistance().set(5);
        options.particles().set(ParticleStatus.MINIMAL);
        options.cloudStatus().set(CloudStatus.OFF);
        options.entityShadows().set(false);
        options.biomeBlendRadius().set(0);
        options.entityDistanceScaling().set(0.5);
        options.mipmapLevels().set(1);
        options.save();
    }

    /** Applies or restores the vanilla particle amount. */
    public static void setParticleReduction(boolean enabled) {
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.options == null) return;
        client.options.particles().set(enabled ? ParticleStatus.MINIMAL : ParticleStatus.ALL);
        client.options.save();
    }

    /** Applies or restores a moderate render distance. */
    public static void setShortRenderDistance(boolean enabled) {
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.options == null) return;
        client.options.renderDistance().set(enabled ? 6 : 12);
        client.options.save();
    }

    /** Reduces the distance at which entities are rendered. This does not change hitboxes or reach. */
    public static void setEntityOptimization(boolean enabled) {
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.options == null) return;
        client.options.entityDistanceScaling().set(enabled ? 0.5 : 1.0);
        client.options.entityShadows().set(!enabled);
        client.options.save();
    }

    /** Stronger preset for very low-end devices; all changes use vanilla client options. */
    public static void applyExtremePreset() {
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.options == null) return;

        var options = client.options;
        options.renderDistance().set(4);
        options.simulationDistance().set(4);
        options.particles().set(ParticleStatus.MINIMAL);
        options.cloudStatus().set(CloudStatus.OFF);
        options.entityShadows().set(false);
        options.entityDistanceScaling().set(0.25);
        options.biomeBlendRadius().set(0);
        options.mipmapLevels().set(0);
        options.save();
    }

    /** Reduces selected first-person visual effects; this improves visual comfort, not raw FPS. */
    public static void setReducedVisualEffects(boolean enabled) {
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.options == null) return;
        client.options.bobView().set(!enabled);
        client.options.screenEffectScale().set(enabled ? 0.0 : 1.0);
        client.options.damageTiltStrength().set(enabled ? 0.0 : 1.0);
        client.options.save();
    }
}
