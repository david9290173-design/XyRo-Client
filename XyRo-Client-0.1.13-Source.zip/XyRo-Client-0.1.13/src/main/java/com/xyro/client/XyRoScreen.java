package com.xyro.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;

/** Original XyRo menu. Module switches are functional client-side UI state. */
public final class XyRoScreen extends Screen {
    private static final int PURPLE = 0xFF9B5CFF;
    private static final int PANEL = 0xF0181421;
    private static final int MUTED = 0xFFAAA2B5;
    private String activeTab = "HOME";
    private final List<Button> tabButtons = new ArrayList<>();

    public XyRoScreen() { super(Component.literal("XyRo Client")); }

    @Override
    protected void init() { rebuildMenu(); }

    private void rebuildMenu() {
        clearWidgets();
        tabButtons.clear();
        String[] tabs = {"HOME", "PVP", "FPS", "COSMETICS", "HUD", "SETTINGS"};
        int panelW = Math.min(520, this.width - 20);
        int left = (this.width - panelW) / 2;
        int panelH = Math.min(420, this.height - 20);
        int top = Math.max(10, (this.height - panelH) / 2);
        int navY = top + 57;
        int navW = Math.max(48, (panelW - 28) / 6 - 2);
        for (int i = 0; i < tabs.length; i++) {
            final String tab = tabs[i];
            Button button = Button.builder(Component.literal(tab), b -> {
                activeTab = tab;
                rebuildMenu();
            }).bounds(left + 12 + i * (navW + 2), navY, navW, 20).build();
            tabButtons.add(button);
            addRenderableWidget(button);
        }
        addRenderableWidget(Button.builder(Component.literal("CLOSE"), b -> onClose())
                .bounds(left + panelW - 72, top + 10, 60, 20).build());

        if ("HUD".equals(activeTab)) {
            addRenderableWidget(Button.builder(Component.literal("EDIT HUD"), b ->
                    net.minecraft.client.Minecraft.getInstance().setScreen(new XyRoHudEditorScreen()))
                    .bounds(left + panelW - 112, top + 91, 88, 20).build());
        }

        String[] modules = modulesFor(activeTab);
        int contentX = left + 24;
        int contentY = top + 119;
        int contentW = panelW - 48;
        int rowStep = Math.max(21, Math.min(25, (panelH - 160) / Math.max(1, modules.length)));
        for (int i = 0; i < modules.length; i++) {
            final String module = modules[i];
            int yy = contentY + i * rowStep - 3;
            if ("Low-End Preset".equals(module) || "Extreme Preset".equals(module)) {
                addRenderableWidget(Button.builder(Component.literal("APPLY"), b -> {
                    if ("Extreme Preset".equals(module)) {
                        XyRoPerformance.applyExtremePreset();
                        notifyPlayer("✦ XyRo Extreme preset applied");
                    } else {
                        XyRoPerformance.applyLowEndPreset();
                        notifyPlayer("✦ XyRo Low-End preset applied");
                    }
                }).bounds(contentX + contentW - 86, yy, 78, 20).build());
            } else {
                addRenderableWidget(Button.builder(toggleLabel(module), b -> {
                    boolean enabled = XyRoModules.toggle(module);
                    if ("Particle Reduction".equals(module)) {
                        XyRoPerformance.setParticleReduction(enabled);
                    } else if ("Short Render Distance".equals(module)) {
                        XyRoPerformance.setShortRenderDistance(enabled);
                    } else if ("Entity Optimization".equals(module)) {
                        XyRoPerformance.setEntityOptimization(enabled);
                    } else if ("Reduced Visual Effects".equals(module)) {
                        XyRoPerformance.setReducedVisualEffects(enabled);
                    }
                    b.setMessage(toggleLabel(module));
                }).bounds(contentX + contentW - 86, yy, 78, 20).build());
            }
        }
    }

    private void notifyPlayer(String message) {
        net.minecraft.client.Minecraft client = net.minecraft.client.Minecraft.getInstance();
        if (client.player != null) client.player.displayClientMessage(Component.literal(message), true);
    }

    private Component toggleLabel(String module) {
        return Component.literal(XyRoModules.isEnabled(module) ? "ON" : "OFF");
    }

    private String[] modulesFor(String tab) {
        return switch (tab) {
            case "PVP" -> new String[]{"CPS Counter", "Combo Counter", "Armor HUD", "Hit Sounds"};
            case "FPS" -> new String[]{"FPS Counter", "Memory Monitor", "Low-End Preset", "Extreme Preset", "Particle Reduction", "Short Render Distance", "Entity Optimization", "Reduced Visual Effects"};
            case "COSMETICS" -> new String[]{"Wings", "Cape", "Cap"};
            case "HUD" -> new String[]{"Keystrokes", "Sprint Indicator", "Potion HUD", "Custom Crosshair"};
            case "SETTINGS" -> new String[]{"Menu Animations", "Compact Layout", "Purple Accent"};
            default -> new String[]{"FPS Counter", "Keystrokes", "Sprint Indicator"};
        };
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int panelW = Math.min(520, this.width - 20);
        int panelH = Math.min(420, this.height - 20);
        int x = (this.width - panelW) / 2;
        int y = (this.height - panelH) / 2;
        g.fill(x + 3, y + 4, x + panelW + 3, y + panelH + 4, 0x80000000);
        g.fill(x, y, x + panelW, y + panelH, 0xFF0B0910);
        g.fill(x, y, x + panelW, y + 2, PURPLE);
        g.fill(x + 1, y + 1, x + panelW - 1, y + panelH - 1, 0xFF100D17);
        g.drawString(font, "✦ XYRO CLIENT", x + 14, y + 13, 0xFFFFFFFF, true);
        g.drawString(font, "BLACK EDITION  •  1.21.11", x + 14, y + 29, MUTED, false);
        g.fill(x + 12, y + 48, x + panelW - 12, y + 49, 0xFF332642);
        g.fill(x + 12, y + 85, x + panelW - 12, y + panelH - 12, PANEL);
        g.fill(x + 12, y + 85, x + 14, y + panelH - 12, PURPLE);
        g.drawString(font, activeTab, x + 24, y + 98, PURPLE, true);
        if ("HOME".equals(activeTab)) {
            g.drawString(font, "LIVE FPS  " + net.minecraft.client.Minecraft.getInstance().getFps(),
                    x + panelW - 112, y + 98, 0xFFE8E0F2, false);
        }
        drawDescriptions(g, x + 24, y + 119);
        g.drawString(font, "PROFILE  XyRoo_X", x + 14, y + panelH - 13, MUTED, false);
        super.render(g, mouseX, mouseY, delta);
    }

    private void drawDescriptions(GuiGraphics g, int x, int y) {
        String[] rows = modulesFor(activeTab);
        int panelH = Math.min(420, this.height - 20);
        int rowStep = Math.max(21, Math.min(25, (panelH - 160) / Math.max(1, rows.length)));
        int panelW = Math.min(520, this.width - 20);
        for (int i = 0; i < rows.length; i++) {
            int yy = y + i * rowStep;
            g.fill(x, yy - 3, x + panelW - 48, yy + 20, 0xFF211A2B);
            g.drawString(font, rows[i], x + 8, yy + 4, 0xFFE8E0F2, false);
            boolean action = "Low-End Preset".equals(rows[i]) || "Extreme Preset".equals(rows[i]);
            String state = action ? "PRESET" : (XyRoModules.isEnabled(rows[i]) ? "ON" : "OFF");
            int stateColor = action || XyRoModules.isEnabled(rows[i]) ? 0xFFB98AFF : MUTED;
            g.drawString(font, state, x + panelW - (action ? 126 : 112), yy + 4, stateColor, true);
            g.fill(x + 3, yy - 2, x + 4, yy + 19, PURPLE);
        }
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
