package com.xyro.client;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

/** Client module states, persisted between game launches. */
public final class XyRoModules {
    private static final Map<String, Boolean> STATES = new LinkedHashMap<>();
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("xyro-client.properties");

    private XyRoModules() {}

    public static void load() {
        if (!Files.isRegularFile(CONFIG)) return;
        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(CONFIG)) {
            properties.load(input);
            for (String name : properties.stringPropertyNames()) {
                STATES.put(name, Boolean.parseBoolean(properties.getProperty(name)));
            }
        } catch (IOException exception) {
            System.err.println("[XyRo] Could not load settings: " + exception.getMessage());
        }
    }

    public static boolean isEnabled(String name) { return STATES.getOrDefault(name, false); }

    public static boolean toggle(String name) {
        boolean next = !isEnabled(name);
        STATES.put(name, next);
        save();
        return next;
    }

    public static void set(String name, boolean enabled) {
        STATES.put(name, enabled);
        save();
    }

    private static void save() {
        Properties properties = new Properties();
        STATES.forEach((name, enabled) -> properties.setProperty(name, Boolean.toString(enabled)));
        try {
            Files.createDirectories(CONFIG.getParent());
            try (OutputStream output = Files.newOutputStream(CONFIG)) {
                properties.store(output, "XyRo Client settings");
            }
        } catch (IOException exception) {
            System.err.println("[XyRo] Could not save settings: " + exception.getMessage());
        }
    }
}
