# XyRo Client 0.1.13 — HUD scaling and colours

An original black-and-purple client-side Fabric mod project for Minecraft 1.21.11.

## New in 0.1.13
- FPS and memory HUD elements can be resized independently from 0.6x to 2.0x.
- Each HUD element can cycle through purple, white, cyan, and amber text colours.
- Scale and colour choices are saved in `config/xyro-hud.properties`.
- The HUD editor previews the selected scale and colour while retaining drag positioning.

## Use
Open the XyRo menu with Right Shift, choose **HUD**, then **EDIT HUD**. Drag a preview to move it. Use the FPS/RAM minus and plus buttons to resize each item, and COLOR to cycle its colour. Press Escape to save and close.

## Build requirements
- Minecraft 1.21.11
- Fabric Loader 0.18.4 or compatible
- Fabric API 0.141.3+1.21.11
- Java 21
- Gradle with Fabric Loom 1.14-SNAPSHOT

This archive contains source code, not a compiled or runtime-tested JAR. A successful Gradle build and in-game test are still required before calling it playable.
